package in.co.test;

public class AdvertiseModelTest {
	
	public static void main(String[] args) {
		testAdd();
	}

	private static void testAdd() {
		
		
	}

}
