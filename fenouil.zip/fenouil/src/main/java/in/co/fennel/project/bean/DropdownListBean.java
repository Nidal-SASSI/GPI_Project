package in.co.fennel.project.bean;

public interface DropdownListBean {
	public String getKey();

	public String getValue();
}
