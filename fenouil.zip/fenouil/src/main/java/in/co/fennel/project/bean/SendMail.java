package in.co.fennel.project.bean;

public class SendMail extends BaseBean {
	
	private String category;

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
